package br.edu.infnet.model;

public enum PerfilEnum {
	ADMINISTRADOR, CLIENTE
}
