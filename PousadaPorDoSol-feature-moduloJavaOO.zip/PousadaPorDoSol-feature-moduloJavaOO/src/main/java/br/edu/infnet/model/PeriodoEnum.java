package br.edu.infnet.model;

public enum PeriodoEnum {
	DIAS_UTEIS, FIM_DE_SEMANA
}
