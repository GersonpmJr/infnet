package br.edu.infnet.model;

public enum TipoQuartoEnum {
	PADRAO, TEMATICO 
}
